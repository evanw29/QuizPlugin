jQuery(document).ready(function($) {

    $('input[name="save_data"]').on('change', function() {
        const saveData = $(this).val() === 'yes';
        const personalInfoSection = $('#personal-info-section');
        
        if (saveData && personalInfoSection.is(':empty')) {
            // Only fetch personal questions if user selected yes and questions haven't been loaded
            $.ajax({
                url: quizAjax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'get_personal_questions',
                    nonce: quizAjax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        personalInfoSection.html(response.data.html).slideDown();
                    }
                }
            });
        } else {
            personalInfoSection.slideToggle();
            
            // Clear values when hiding
            if (!saveData) {
                personalInfoSection.find('input').val('');
            }
        }
    });

    //When the submit button is pressed, collect and send data to db
    $('#quiz-form').on('submit', function(e) {
        e.preventDefault();

        const form = $(this);
        const formMessage = $('#form-message');
        const submitButton = form.find('button[type="submit"]');
        const saveData = $('input[name="save_data"]:checked').val() === 'yes';
        
        //Disable submit button to prevent double submission
        submitButton.prop('disabled', true);
        
        //create empty array for all responses
        let responses = {};
        
        //Process each question group
        $('.question-group').each(function() {
            const questionId = $(this).data('question-id');
            const inputs = $(this).find('input:checked, select, input[type="text"]');
            
            //Get multiple answers in case of checkbox question type
            if (inputs.length) {
                if (inputs.is(':checkbox')) {
                    responses[questionId] = [];
                    inputs.each(function() {
                        responses[questionId].push($(this).val());
                    });
                } else {
                    responses[questionId] = inputs.val();
                }
            }
        });

        //Add personal info if user has chosen so
        if (saveData) {
            const personalInfoFields = $('.personal-info');
            let isValid = true;
            
            personalInfoFields.each(function() {
                if (!$(this).val()) {
                    isValid = false;
                    $(this).closest('.question-group').addClass('error');
                } else {
                    $(this).closest('.question-group').removeClass('error');
                    const questionId = $(this).closest('.question-group').data('question-id');
                    responses[questionId] = $(this).val();
                }
            });

            if (!isValid) {
                formMessage.html('<div class="error">Please fill in all required fields.</div>');
                submitButton.prop('disabled', false);
                return;
            }
        }

        //Send AJAX request
        $.ajax({
            url: quizAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'handle_quiz_submission',
                nonce: quizAjax.nonce,
                responses: responses
            }, 
            success: function(response) {

                submitButton.prop('disabled', false);
                
                if (response.success) {
                    formMessage.html('<div class="success">' + response.data.message + '</div>');
                    form.hide();
                } else {
                    formMessage.html('<div class="error">Error: ' + (response.data || 'Unknown error occurred') + '</div>');
                }
            },
            error: function(xhr, status, error) {
                submitButton.prop('disabled', false);
                formMessage.html('<div class="error">Error submitting form. Please try again.</div>');
            }
        });
    });
});